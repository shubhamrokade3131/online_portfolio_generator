from django.shortcuts import render
from flask import Flask, render_template, request, send_file
import pdfkit
import os



app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/form')
def form():
    return render_template('form.html')

@app.route('/preview', methods=['POST'])
def preview():
    data = request.form.to_dict()
    image = request.files.get('profile_image')
    image_filename = None
    if image:
        image_filename = os.path.join(app.config['UPLOAD_FOLDER'], image.filename)
        image.save(image_filename)
        data['profile_image'] = f'uploads/{image.filename}'
    else:
        data['profile_image'] = ''
    return render_template('preview.html', data=data, profile_image=data['profile_image'])

@app.route('/download-pdf', methods=['POST'])
def download_pdf():
    data = request.form.to_dict()
    profile_image = data.get('profile_image', '')
    rendered = render_template('preview.html', data=data, profile_image=profile_image)
    
    # Save the PDF
    pdf_file = 'portfolio.pdf'
    import pdfkit

    # Manually set the path to wkhtmltopdf.exe
    config = pdfkit.configuration(wkhtmltopdf=r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe')

    pdfkit.from_string(rendered, pdf_file, configuration=config)
    return send_file(pdf_file, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
